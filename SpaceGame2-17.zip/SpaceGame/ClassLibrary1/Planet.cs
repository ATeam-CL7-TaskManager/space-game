﻿using System;
using System.Xml;

namespace SpaceClassLibrary
{
    public class Planet
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Size { get; set; }
        public string Inventory { get; set; }

        //xmlstuff going on here. Left in in case we want to use it later on.
        //public string explName { get; set; }
        //public double explVal { get; set; }
        //public string fuelName { get; set; }
        //public double fuelVal { get; set; }
        //public string foodName { get; set; }
        //public double foodVal { get; set; }
        //public string radMedName { get; set; }
        //public double radMedVal { get; set; }
        //public string orbsName { get; set; }
        //public double orbsVal { get; set; }
        public void Explore()
        {
            Console.WriteLine(Description);
            Console.WriteLine($"Size: {Size}km");
            Console.WriteLine($"Planet vendor {Inventory}");
        }
        public void Buy()
        {
            Console.WriteLine($"What are you looking for? {Inventory}");
        }
        public void Leave()
        {
            Console.WriteLine("Select L to confirm decision");
        }
        public void Welcome()
        {

            //if the input by the user parses to an integer and is between 1 and 5, return the input.
            
            int onplanet = 0;
            while (onplanet == 0)
            {
                Console.WriteLine("Welcome to " + this.Name);
                Console.WriteLine("Would you like to:\n1) Explore\n2) Buy\n3) Sell\n4) Leave");
                string temp;
                int tempInt;
                int input = 0;
                temp = Console.ReadLine();
                if (int.TryParse(temp, out tempInt) && (tempInt >= 1 && tempInt <= 4))
                {
                    input = tempInt;
                }
                else
                {
                    //if the input by the user doesnt parse to an integer or is not between 1 and 5, do not return the input. Loop until user enters an acceptable value.
                    Console.WriteLine("Please enter a nubmer listed above and press enter.");
                    while (!int.TryParse(Console.ReadLine(), out tempInt) || (tempInt < 1 || tempInt > 4))
                    {
                        Console.WriteLine("Please enter a nubmer listed above and press enter.");
                    }
                    input = tempInt;
                }
                switch (input)
                {
                    case 1: //Explore
                        this.Explore();
                        Console.ReadKey();
                        break;
                    case 2: //Buy
                        this.Buy();
                        Console.ReadKey();
                        break;
                    case 3: //Sell
                        this.Buy();
                        Console.ReadKey();
                        break;
                    case 4: //Leave
                        Console.WriteLine($"You wave goodbye to the citizens of {this.Name} as your scooter takes off.\nPress enter to head back to space.");
                        Console.ReadLine();
                        onplanet = 1;
                        break;
                }
            }
            
        }
   
        
    }
}
