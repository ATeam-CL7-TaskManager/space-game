﻿using System;
using System.Xml;

namespace SpaceClassLibrary
{
    public class Planet
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Size { get; set; }
        public Items Inventory { get; set; }

        Player newPlayer = new Player();

        public void newPlayerInventory()
        {
            Console.WriteLine($"Player Inventory:\n" +
                $"Spaceoes: {newPlayer.SpaceosAmount}\n" +
                $"Food: {newPlayer.FoodAmount}\n" +
                $"Tools: {newPlayer.ToolAmount}\n" +
                $"Explodium: {newPlayer.ExplodiumAmount}\n" +
                $"Fuel: {newPlayer.FuelAmount}\n");
        }
        public void ToolsBuySell()
        {
            bool trading = true;
            int newInput;
            string inputQty;
            do
            {
                Console.Clear();
                Console.WriteLine("Choose a number: \n1) Buy \n2) Sell \n3) Exit");
                int choiceInput = Int32.Parse(Console.ReadLine());

                switch (choiceInput)
                {
                    case 1:
                        {
                            Console.WriteLine($"Please enter the amount of {Inventory.ToolName} you want to buy!");
                            newInput = Convert.ToInt32(Console.ReadLine());

                            if (newInput * Inventory.ToolSalePrice < newPlayer.SpaceosAmount)
                            {
                                newPlayer.SpaceosAmount -= (newInput * Inventory.ToolSalePrice);
                                newPlayer.ToolAmount += newInput;
                                Inventory.ToolQuantity -= newInput;
                                Console.WriteLine($"You purchased {newInput} explodium");
                                Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.ToolAmount}");
                                Console.WriteLine("Hit enter to continue!");
                                Console.ReadLine();
                            }
                            else if (newInput * Inventory.ToolSalePrice > newPlayer.SpaceosAmount)
                            {
                                Console.WriteLine("You dont have enough money!\n" +
                                    "Hit enter to return to the menu.");
                                Console.ReadLine();
                            }
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine($"Please enter the amount of {Inventory.ToolName} you want to sell!");
                            newInput = Convert.ToInt32(Console.ReadLine());

                            if (newInput <= newPlayer.ToolAmount)
                            {
                                newPlayer.SpaceosAmount += (newInput * Inventory.ToolBuyPrice);
                                newPlayer.ToolAmount -= newInput;
                                Inventory.ToolQuantity += newInput;
                                Console.WriteLine($"You Sold {newInput} explodium");
                                Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.ToolAmount} ");
                                Console.WriteLine("Hit enter to continue!");
                                Console.ReadLine();
                            }
                            else if (newInput > newPlayer.ToolAmount)
                            {
                                Console.WriteLine("You do not have enough in your inventory!\n" +
                                    "Press any key to return to the menu!");
                                Console.ReadLine();
                            }
                            break;
                        }
                    case 3:
                        {
                            trading = false;
                            break;
                        }

                }
            } while (trading == true);

        }

    
        public void ExplodiumBuySell()
        {
            bool trading = true;
            int newInput;
            string inputQty;
                do
                {
                Console.Clear();
                Console.WriteLine("Choose a number: \n1) Buy \n2) Sell \n3) Exit");
                    int choiceInput = Int32.Parse(Console.ReadLine());

                    switch (choiceInput)
                    {
                        case 1:
                            {
                                Console.WriteLine($"Please enter the amount of {Inventory.ExplodiumName} you want to buy!");
                                newInput = Convert.ToInt32(Console.ReadLine());

                                if (newInput * Inventory.ExplodiumSalePrice < newPlayer.SpaceosAmount)
                                {
                                    newPlayer.SpaceosAmount -= (newInput * Inventory.ExplodiumSalePrice);
                                    newPlayer.ExplodiumAmount += newInput;
                                    Inventory.ExplodiumQuantity -= newInput;
                                    Console.WriteLine($"You purchased {newInput} explodium");
                                    Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.ExplodiumAmount}");
                                    Console.WriteLine("Hit enter to continue!");
                                    Console.ReadLine();
                                }
                                else if (newInput * Inventory.ExplodiumSalePrice > newPlayer.SpaceosAmount)
                                {
                                    Console.WriteLine("You dont have enough money!\n" +
                                        "Hit enter to return to the menu.");
                                    Console.ReadLine();
                                }
                            break;
                            }

                        case 2:
                            {
                                Console.WriteLine($"Please enter the amount of {Inventory.ExplodiumName} you want to sell!");
                                newInput = Convert.ToInt32(Console.ReadLine());

                            if (newInput <= newPlayer.ExplodiumAmount)
                                {
                                    newPlayer.SpaceosAmount += (newInput * Inventory.ExplodiumBuyPrice);
                                    newPlayer.ExplodiumAmount -= newInput;
                                    Inventory.ExplodiumQuantity += newInput;
                                    Console.WriteLine($"You Sold {newInput} explodium");
                                    Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.ExplodiumAmount} ");
                                    Console.WriteLine("Hit enter to continue!");
                                    Console.ReadLine();
                                }
                                else if (newInput > newPlayer.ExplodiumAmount)
                                {
                                    Console.WriteLine("You do not have enough in your inventory!\n" +
                                        "Press any key to return to the menu!");
                                    Console.ReadLine();
                                }
                            break;
                            }
                        case 3:
                            {
                            trading = false;
                            break;
                            }
                        
                    }
                } while (trading == true);
            
        }
        public void FuelBuySell()
            {
                bool trading = true;
                int newInput;
                string inputQty;
                do
                {
                Console.Clear();
                Console.WriteLine("Choose a number: \n1) Buy \n2) Sell \n3) Exit");
                    int choiceInput = Int32.Parse(Console.ReadLine());

                    switch (choiceInput)
                    {
                        case 1:
                            {
                                Console.WriteLine($"Please enter the amount of {Inventory.FuelName} you want to buy!");
                                newInput = Convert.ToInt32(Console.ReadLine());

                                if (newInput * Inventory.FuelSalePrice < newPlayer.SpaceosAmount)
                                {
                                    newPlayer.SpaceosAmount -= (newInput * Inventory.FuelSalePrice);
                                    newPlayer.FuelAmount += newInput;
                                    Inventory.FuelQuantity -= newInput;
                                    Console.WriteLine($"You purchased {newInput} Fuel");
                                    Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.FuelAmount}");
                                    Console.WriteLine("Hit enter to continue!");
                                    Console.ReadLine();
                                }
                                else if (newInput * Inventory.FuelSalePrice > newPlayer.SpaceosAmount)
                                {
                                    Console.WriteLine("You dont have enough money!\n" +
                                        "Hit enter to return to the menu.");
                                    Console.ReadLine();
                                }
                                break;
                            }

                        case 2:
                            {
                                Console.WriteLine($"Please enter the amount of {Inventory.FuelName} you want to sell!");
                                newInput = Convert.ToInt32(Console.ReadLine());

                            if (newInput <= newPlayer.FuelAmount)
                                {
                                    newPlayer.SpaceosAmount += (newInput * Inventory.FuelBuyPrice);
                                    newPlayer.FuelAmount -= newInput;
                                    Inventory.FuelQuantity += newInput;
                                    Console.WriteLine($"You Sold {newInput} Fuel");
                                    Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.FuelAmount} ");
                                    Console.WriteLine("Hit enter to continue!");
                                    Console.ReadLine();
                                }
                                else if (newInput > newPlayer.FuelAmount)
                                {
                                    Console.WriteLine("You do not have enough in your inventory!\n" +
                                        "Press any key to return to the menu!");
                                    Console.ReadLine();
                                }
                                break;
                            }
                        case 3:
                            {
                                trading = false;
                                break;
                            }

                    }
                } while (trading == true);

            }

        public void FoodBuySell()
        {
            bool trading = true;
            int newInput;
            string inputQty;
            do
            {
                Console.Clear();
                Console.WriteLine("Choose a number: \n1) Buy \n2) Sell \n3) Exit");
                int choiceInput = Int32.Parse(Console.ReadLine());

                switch (choiceInput)
                {
                    case 1:
                        {
                            Console.WriteLine($"Please enter the amount of {Inventory.FoodName} you want to buy!");
                            newInput = Convert.ToInt32(Console.ReadLine());

                            if (newInput * Inventory.FoodSalePrice < newPlayer.SpaceosAmount)
                            {
                                newPlayer.SpaceosAmount -= (newInput * Inventory.FoodSalePrice);
                                newPlayer.FoodAmount += newInput;
                                Inventory.FoodQuantity -= newInput;
                                Console.WriteLine($"You purchased {newInput} Food");
                                Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.FoodAmount}");
                                Console.WriteLine("Hit enter to continue!");
                                Console.ReadLine();
                            }
                            else if (newInput * Inventory.FoodSalePrice > newPlayer.SpaceosAmount)
                            {
                                Console.WriteLine("You dont have enough money!\n" +
                                    "Hit enter to return to the menu.");
                                Console.ReadLine();
                            }
                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine($"Please enter the amount of {Inventory.FoodName} you want to sell!");
                            inputQty = Console.ReadLine();
                            newInput = Int32.Parse(inputQty);


                            if (newInput <= newPlayer.FoodAmount)
                            {
                                newPlayer.SpaceosAmount += (newInput * Inventory.FoodBuyPrice);
                                newPlayer.FoodAmount -= newInput;
                                Inventory.FoodQuantity += newInput;
                                Console.WriteLine($"You Sold {newInput} Food");
                                Console.WriteLine($"You now have {newPlayer.SpaceosAmount} of spaceos AND {newPlayer.FoodAmount} ");
                                Console.WriteLine("Hit enter to continue!");
                                Console.ReadLine();
                            }
                            else if (newInput > newPlayer.FoodAmount)
                            {
                                Console.WriteLine("You do not have enough in your inventory!\n" +
                                    "Press any key to return to the menu!");
                                Console.ReadLine();
                            }
                            break;
                        }
                    case 3:
                        {
                            trading = false;
                            break;
                        }

                }
            } while (trading == true);
        }

    
        public void BuySell()
        {
            Console.Clear();
            bool condition = true;
            newPlayerInventory();
            Console.WriteLine();
            Console.WriteLine($"Welcome to the {this.Name} Inventory!");
            
            while (condition == true)
            {
                string select = "";
                Console.WriteLine($"Select the number of the item you wish to sell or purchase! \n" +
                  $"1) {Inventory.FoodName}  Buy Price : {Inventory.FoodBuyPrice} Sell Price: {Inventory.FoodSalePrice} \n" +
                  $"2) {Inventory.FuelName} Buy Price : {Inventory.FuelBuyPrice} Sell Price: {Inventory.FuelSalePrice} \n" +
                  $"3) {Inventory.ExplodiumName} Buy Price : {Inventory.ExplodiumBuyPrice} Sell Price: {Inventory.ExplodiumSalePrice} \n" +
                  $"4) {Inventory.ToolName}  Buy Price : {Inventory.ToolBuyPrice} Sell price: {Inventory.ToolSalePrice} \n" +
                  $"5) Exit");
                select = Console.ReadLine();
                switch (select)
                {
                    case "1":
                        this.FoodBuySell();
                        break;
                    case "2":
                        this.FuelBuySell();
                        break;
                    case "3":
                        this.ExplodiumBuySell();
                        break;
                    case "4":
                        this.ToolsBuySell();
                        break;
                    case "5":
                        condition = false;
                        break;
                    default:
                        Console.WriteLine("Please enter a correct number!");
                        select = Console.ReadLine();
                        condition = true;
                        break;
                }
                continue;
            }
        }
        public void Explore()
        {
            Console.WriteLine(Description);
            Console.WriteLine($"Size: {Size}km");
            Console.WriteLine($"Planet vendor {Inventory}");
        }     
        public void Leave()
        {
            Console.WriteLine("Select L to confirm decision");
        }
        public void Welcome()
        {

            //if the input by the user parses to an integer and is between 1 and 5, return the input.
            
            int onplanet = 0;
            while (onplanet == 0)
            {           
                Console.WriteLine("Welcome to " + this.Name);
                Console.WriteLine("Would you like to:\n1) Explore\n2) Buy and Sell \n3) Leave");
                string temp;
                int tempInt;
                int input = 0;
                temp = Console.ReadLine();
                if (int.TryParse(temp, out tempInt) && (tempInt >= 1 && tempInt <= 4))
                {
                    input = tempInt;
                }
                else
                {
                    //if the input by the user doesnt parse to an integer or is not between 1 and 5, do not return the input. Loop until user enters an acceptable value.
                    Console.WriteLine("Please enter a nubmer listed above and press enter.");
                    while (!int.TryParse(Console.ReadLine(), out tempInt) || (tempInt < 1 || tempInt > 4))
                    {
                        Console.WriteLine("Please enter a nubmer listed above and press enter.");
                    }
                    input = tempInt;
                }
                switch (input)
                {
                    case 1: //Explore
                        this.Explore();
                        Console.ReadKey();
                        break;
                    case 2: //Buy
                        this.BuySell();
                        Console.ReadKey();
                        break;
                    case 3: //Leave
                        Console.WriteLine($"You wave goodbye to the citizens of {this.Name} as your scooter takes off.\nPress enter to head back to space.");
                        Console.WriteLine($"You used 10 gallons a fuel during your travel!\n" +
                        $"You have {newPlayer.FuelAmount - 10} gallons left");
                        Console.ReadLine();
                        onplanet = 1;
                        break;
                }
                continue;
            }
            
        }
      
    }
}
