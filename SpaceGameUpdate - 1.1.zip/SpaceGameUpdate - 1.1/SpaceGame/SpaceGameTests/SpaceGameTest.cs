using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SpaceGameTests
{
    [TestClass]
    public class SpaceGameTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
