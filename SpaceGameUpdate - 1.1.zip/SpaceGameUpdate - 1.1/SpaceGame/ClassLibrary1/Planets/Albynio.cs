﻿using System;
using System.Xml;

namespace SpaceClassLibrary
{
    public class Albynio : Planet
    {     

        public Albynio()
        {
            this.Name = "Albynio";
            this.Size = 10000;
            this.Description = ("A relativley small planet where all matter lacks any kind of pigment.\n" +
                "While not understood completley the planet is the only source of Neoplasmin Cubes in the sector\n" +
                "The weather is -20 degrees, Atmosphere reading:\n" +
                "No atmosphere\n" +
                "Best to stay on your scooter and let the drones do the trading.");
            Items AlbynioInventory = new AlbynioInventory();
            this.Inventory = AlbynioInventory;
            

            ////load the XML doc into C#
            //XmlDocument AlbInv = new XmlDocument();
            //AlbInv.Load("AlbInv.xml");

            ////set the root value of the document.
            //XmlElement root = AlbInv.DocumentElement;

            ////instantiate objects for our nodes and set their values to the matching vlaues in our XML doc
            //XmlNode ExplName = root.SelectSingleNode("/items/Explodium/name");
            //XmlNode ExplVal = root.SelectSingleNode("/items/Explodium/value");
            //XmlNode FuelName = root.SelectSingleNode("/items/Fuel/name");
            //XmlNode FuelVal = root.SelectSingleNode("/items/Fuel/value");
            //XmlNode FoodName = root.SelectSingleNode("/items/food/name");
            //XmlNode FoodVal = root.SelectSingleNode("/items/food/value");
            //XmlNode RadMedName = root.SelectSingleNode("/items/Radiation_Meds/name");
            //XmlNode RadMedVal = root.SelectSingleNode("/items/Radiation_Meds/value");
            //XmlNode OrbsName = root.SelectSingleNode("/items/Orbs/name");
            //XmlNode OrbsVal = root.SelectSingleNode("/items/Orbs/value");

            //this.explName = ExplName.InnerText;
            //this.explVal = Convert.ToDouble(ExplVal.InnerText);
            //this.fuelName = FuelName.InnerText;
            //this.fuelVal = Convert.ToDouble(FuelVal.InnerText);
            //this.foodName = FoodName.InnerText;
            //this.foodVal = Convert.ToDouble(FoodVal.InnerText);
            //this.radMedName = RadMedName.InnerText;
            //this.radMedVal = Convert.ToDouble(RadMedVal.InnerText);
            //this.orbsName = OrbsName.InnerText;
            //this.orbsVal = Convert.ToDouble(OrbsVal.InnerText);

            

            //this.Inventory = ($"Welcome to the market! Prices here on {this.Name} are as follows:" +
            //    $"\n{this.explName} costs {this.explVal}" +
            //    $"\n{this.foodName} costs {this.foodVal}" +
            //    $"\n{this.fuelName} costs {this.fuelVal}" +
            //    $"\n{this.radMedName} costs {this.radMedVal}" +
            //    $"\n{this.orbsName} costs {this.orbsVal}");
        }
    }
}
