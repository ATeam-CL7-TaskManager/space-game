﻿using System;
using SpaceClassLibrary;
using System.Xml;
namespace SpaceClassLibrary
{
    class Program
    {
        static void Main(string[] args)
        {
            //instantiate planets with their own names.
            Jamestown Jamestown = new Jamestown();
            Davesanity Davesanity = new Davesanity();
            Carsonopolis Carsonopolis = new Carsonopolis();
            Albynio Albynio = new Albynio();
            Lenoritarium Lenoritarium = new Lenoritarium();
            
            //instantiate player and scooter, user selects names for each and is introduced.
            Player player = new Player();
            Scooter scooter = new Scooter();
            player.StartScreen(); //print start screen
            player.SelectName(); 
            scooter.SelectName();
            Console.WriteLine($"Hello, {player.Name}! you are travelling through space on your trusty scooter, {scooter.Name}.");

            //player selects a planet
            int run = 0;
            while (run == 0)
            {
                int planetSelection = player.PlanetSelector();
                switch (planetSelection)
                {
                    case 1:
                        Albynio.Welcome();
                        break;
                    case 2:
                        Carsonopolis.Welcome();
                        break;
                    case 3:
                        Davesanity.Welcome();
                        break;
                    case 4:
                        Jamestown.Welcome();
                        break;
                    case 5:
                        Lenoritarium.Welcome();                 
                        break;
                }
                continue;
            }

            if (player.SpaceosAmount > 10000)
            {
                Console.WriteLine("Congradulations, You have won the game!");
 
            }
        }
        
    }
}
