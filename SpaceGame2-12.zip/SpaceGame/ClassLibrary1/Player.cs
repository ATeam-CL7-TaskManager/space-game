﻿using System;
using System.Xml;


namespace SpaceClassLibrary
{

    public class Player
    {
        public string Name { get; set; } = "Traveler";

        //inventory fields
        public string FoodName = "Food";
        public int FoodAmount = 5;

        public string FuelName = "Fuel";
        public int FuelAmount = 20;

        public string ToolName = "Tools";
        public int ToolAmount = 0;

        public string ExplodiumName = "Explodium";
        public int ExplodiumAmount = 0;

        public string SpaceosName = "Spaceos";
        public int SpaceosAmount = 100;
        
        public void StartScreen()
        {
            Console.WriteLine("Welcome to Space!\n Press any key to begin playing...");
            Console.ReadKey();
        }
        public void SelectName()
        {
            Console.WriteLine("Enter Your Name:");
            string inputname = Console.ReadLine();
            this.Name = inputname;
        }

    }
}
