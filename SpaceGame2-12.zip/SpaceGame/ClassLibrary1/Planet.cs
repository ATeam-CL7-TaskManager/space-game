﻿using System;
using System.Xml;

namespace SpaceClassLibrary
{
    public class Planet
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Size { get; set; }
        public string Inventory { get; set; }
        //public string explName { get; set; }
        //public double explVal { get; set; }
        //public string fuelName { get; set; }
        //public double fuelVal { get; set; }
        //public string foodName { get; set; }
        //public double foodVal { get; set; }
        //public string radMedName { get; set; }
        //public double radMedVal { get; set; }
        //public string orbsName { get; set; }
        //public double orbsVal { get; set; }
        public void Explore()
        {
            Console.WriteLine(Description);
            Console.WriteLine($"Size: {Size}km");
            Console.WriteLine($"Planet vendor {Inventory}");
        }
        public void Buy()
        {
            Console.WriteLine($"What are you looking for? {Inventory}");
        }
        public void Leave()
        {
            Console.WriteLine("Select L to confirm decision");
        }
   
        
    }
}
