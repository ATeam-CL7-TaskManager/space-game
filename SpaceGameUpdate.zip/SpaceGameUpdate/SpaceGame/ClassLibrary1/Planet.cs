﻿using System;
using System.Xml;

namespace SpaceClassLibrary
{
    public class Planet
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Size { get; set; }
        public  Items Inventory { get; set; }
        public Player player { get; set; }

        public void Explore()
        {
            Console.WriteLine(Description);
            Console.WriteLine($"Size: {Size}km");
            // Console.WriteLine($"Planet vendor {Inventory}");
        }
        public void Buy()
        {
            string select;
            int selectInt = 0;

                Console.WriteLine($"Select the item you wish to purchase \n" +
                $"1) {Inventory.FoodName}  Price : {Inventory.FoodBuyPrice} \n" +
                $"2) {Inventory.FuelName} Price : {Inventory.FuelBuyPrice} \n" +
                $"3) {Inventory.ExplodiumName} Price : {Inventory.ExplodiumBuyPrice} \n" +
                $"4) {Inventory.ToolName}  Price : {Inventory.ToolBuyPrice} \n " +
                $"5) Exit");

                select = Console.ReadLine();
                while (!int.TryParse(select, out selectInt))
                {
                    Console.WriteLine("Please enter a correct number!");
                }
                selectInt = int.Parse(select); 
                
                if (selectInt < 1 && selectInt > 5)
                {
                Console.WriteLine("Please enter a correct number!");
                }
                else if (selectInt == 1)
                {
                    this.buyFood();
                }
                else if (selectInt == 2)
                {
                    this.buyFuel();
                }
                else if (selectInt == 3)
                {
                    this.buyExplodium();
                }
                else if (selectInt == 4)
                {
                    this.buyTools();
                }
                else if (selectInt == 5)
                {
                    this.Welcome();
                    Console.ReadKey();
                }
                

        }
        public void Leave()
        {
            Console.WriteLine("Select L to confirm decision");
        }
        public void Welcome()
        {
            Console.WriteLine("Welcome to " + this.Name);
            Console.WriteLine("Would you like to:\n1) Explore\n2) Buy\n3) Sell\n4) Leave");
            string temp;
            int tempInt;
            int input = 0;
            temp = Console.ReadLine();
            //if the input by the use parses to an integer and is between 1 and 5, return the input.
            if (int.TryParse(temp, out tempInt) && (tempInt >= 1 && tempInt <= 4))
            {
                input = tempInt;
            }
            else
            {
                //if the input by the user doesnt parse to an integer or is not between 1 and 5, do not return the input. Loop until user enters an acceptable value.
                Console.WriteLine("Please enter a nubmer listed above and press enter.");
                while (!int.TryParse(Console.ReadLine(), out tempInt) || (tempInt < 1 || tempInt > 4))
                {
                    Console.WriteLine("Please enter a nubmer listed above and press enter.");
                }
                input = tempInt;
            }
            switch (input)
            {
                case 1: //Explore
                    this.Explore();
                    Console.ReadKey();
                    break;
                case 2: //Buy
                    this.Buy();
                    Console.ReadKey();
                    break;
                case 3: //Sell
                    this.Buy();
                    Console.ReadKey();
                    break;
                case 4: //Leave
                    break;            
            }
            
        }
   
        public void buyFood()
        {
            int newInput = 0;
            string inputQty;
            Console.WriteLine($"Please enter the amount of {Inventory.FoodName} you want to buy!");

            try
            {
                bool condition = true;
                while (condition)
                {
                    inputQty = Console.ReadLine();
                    newInput = int.Parse(inputQty);

                    if (newInput * Inventory.FoodBuyPrice < player.SpaceosAmount)
                    {
                        player.SpaceosAmount -= (newInput * Inventory.FoodBuyPrice);
                        player.FoodAmount += newInput;
                        Inventory.FoodQuantity -= newInput;
                        Console.WriteLine($"You purchased {newInput} items of food");
                        Console.WriteLine($"You now have {player.SpaceosAmount} of spaceos AND {player.FoodAmount} items of food");
                        Console.WriteLine("Hit enter to continue!");
                        Console.ReadLine();
                        this.Buy();
                    }
                    else
                    {
                        Console.WriteLine("Please Enter a correct number!");
                        condition = true;
                    }
                }
            }
            catch (FormatException)
            {
                this.buyFood();
            }

        }
        public void buyFuel()
        {
            int newInput = 0;
            string inputQty;
            Console.WriteLine($"Please enter the amount of {Inventory.FuelName} you want to buy!");

            try
            {
                bool condition = true;
                while (condition)
                {
                    inputQty = Console.ReadLine();
                    newInput = int.Parse(inputQty);

                    if (newInput * Inventory.FuelBuyPrice < player.SpaceosAmount)
                    {
                        player.SpaceosAmount -= (newInput * Inventory.FuelBuyPrice);
                        player.FuelAmount += newInput;
                        Inventory.FuelQuantity -= newInput;
                        Console.WriteLine($"You purchase {newInput} gallons of Fuel");
                        Console.WriteLine($"You now have {player.SpaceosAmount} of spaceos AND {player.FuelAmount} gallons of Fuel");
                        Console.WriteLine("Hit enter to continue!");
                        Console.ReadLine();
                        this.Buy();
                    }
                    else
                    {
                        Console.WriteLine("Please Enter a correct number!");
                        condition = true;
                    }
                }
            }
            catch (FormatException)
            {               
                this.buyFuel();
            }
                       
        }

        public void buyExplodium()
        {
            int newInput = 0;
            string inputQty;
            Console.WriteLine($"Please enter the amount of {Inventory.ExplodiumName} you want to buy!");

            try
            {
                bool condition = true;
                while (condition)
                {
                    inputQty = Console.ReadLine();
                    newInput = int.Parse(inputQty);

                    if (newInput * Inventory.ExplodiumBuyPrice < player.SpaceosAmount)
                    {
                        player.SpaceosAmount -= (newInput * Inventory.ExplodiumBuyPrice);
                        player.ExplodiumAmount += newInput;
                        Inventory.ExplodiumQuantity -= newInput;
                        Console.WriteLine($"You purchased {newInput} Explodium");
                        Console.WriteLine($"You now have {player.SpaceosAmount} of spaceos AND {player.ExplodiumAmount} Explodium");
                        Console.WriteLine("Hit enter to continue!");
                        Console.ReadLine();
                        this.Buy();
                    }
                    else
                    {
                        Console.WriteLine("Please Enter a correct number!");
                        condition = true;
                    }
                }
            }
            catch (FormatException)
            {
                this.buyExplodium();
            }
        }

        public void buyTools()
        {
            int newInput = 0;
            string inputQty;
            Console.WriteLine($"Please enter the amount of {Inventory.ToolName} you want to buy!");

            try
            {
                bool condition = true;
                while (condition)
                {
                    inputQty = Console.ReadLine();
                    newInput = int.Parse(inputQty);

                    if (newInput * Inventory.ToolBuyPrice < player.SpaceosAmount)
                    {
                        player.SpaceosAmount -= (newInput * Inventory.ToolBuyPrice);
                        player.ToolAmount += newInput;
                        Inventory.ToolQuantity -= newInput;
                        Console.WriteLine($"You purchased {newInput} Tools");
                        Console.WriteLine($"You now have {player.SpaceosAmount} of spaceos AND {player.ToolAmount} Tools");
                        Console.WriteLine("Hit enter to continue!");
                        Console.ReadLine();
                        this.Buy();
                    }
                    else
                    {
                        Console.WriteLine("Please Enter a correct number!");
                        condition = true;
                    }
                }
            }
            catch (FormatException)
            {
                this.buyTools();
            }
        }
    }
}
