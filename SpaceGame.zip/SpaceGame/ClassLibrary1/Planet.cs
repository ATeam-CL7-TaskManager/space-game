﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetClassLibrary
{
    public class Planet
    {
        public string name;
        public string description;
        public int size;
        public string inventory;



        public void Explore()
        {
            Console.WriteLine(description);
            Console.WriteLine($"Size: {size}km");
            Console.WriteLine($"Planet vendor {inventory}");
        }

        public void Buy()
        {
            Console.WriteLine($"What are you looking for? {inventory}");
        }

        public void Leave()
        {
            Console.WriteLine("Select L to confirm decision");
        }





    }
}
