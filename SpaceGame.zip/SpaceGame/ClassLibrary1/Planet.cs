﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceClassLibrary
{
    public class Planet
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Size { get; set; }
        public string Inventory { get; set; }
        public void Explore()
        {
            Console.WriteLine(Description);
            Console.WriteLine($"Size: {Size}km");
            Console.WriteLine($"Planet vendor {Inventory}");
        }

        public void Buy()
        {
            Console.WriteLine($"What are you looking for? {Inventory}");
        }

        public void Leave()
        {
            Console.WriteLine("Select L to confirm decision");
        }
   
        
    }
}
