﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceClassLibrary
{

    public class Player
    {

        public string Name { get; set; } = "Traveler";
        public void StartScreen()
        {
            Console.WriteLine("Welcome to Space!\n Press any key to begin playing...");
            Console.ReadKey();
        }
        public void SelectName()
        {
            Console.WriteLine("Enter Your Name:");
            string inputname = Console.ReadLine();
            this.Name = inputname;
        }

        
      
    }
}
