﻿using System;

namespace PlanetClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            Planet Jamestown = new Planet();
            Jamestown.name = "Jamestown";
            Jamestown.size = 25000;
            Jamestown.description = ("A lush forest planet home to many dangerous species of flora and fauna.\n" +
                "Many deep veins of explodium keep the mining towns operational and profitable.\n" +
                "The weather is currently 72 degrees, Atmosphere reading:\nO2 52%\n" +
                "Nitrogen 20%\n" +
                "Methane 28%\n" +
                "Perfect weather for fishing for Jamesian Snappers!");
            Jamestown.inventory = ("Explodium, Fuel, Ice cream");
            

            Planet Davesanity = new Planet();
            Davesanity.name = "Davesanity";
            Davesanity.size = 20000;
            Davesanity.description = ("An ocean world teeming with aquatic life and natural wonders hidden under an amethyst sea\n" +
                "Also home to many of the materials required to make radiation meds making this world a hub of medical production\n" +
                "The weather is currently 60 degrees, Atmosphere reading:\n" +
                "O2 75%\n" +
                "CO2 15%\n" +
                "Nitrogen 10%\n" +
                "Excellent surf conditions to catch a wave or two!");
            Davesanity.inventory = ("Radiation meds, Food");
            

            Planet Carsonopolis = new Planet();
            Carsonopolis.name = "Carsonopolis";
            Carsonopolis.size = 30000;
            Carsonopolis.description = ("A massive planet dedicated to corporate production, almost all space scooters in the sector are produced here\n" +
                "Tools of all kinds from the common HyperScrewdriver to the commercial Spatial Relocator are exported from here\n" +
                "The weather is 10 degrees, Atmosphere reading:\n" +
                "O2 15%\n" +
                "CO2 80%\n" +
                "Nitrogen 5%\n" +
                "Perfect conditions for staying in the climate controlled factories and continuing work!");
            Carsonopolis.inventory = ("Tools, Fuel");
            

            Planet Albynio = new Planet();
            Albynio.name = "Albynio";
            Albynio.size = 10000;
            Albynio.description = ("A relativley small planet where all matter lacks any kind of pigment.\n" +
                "While not understood completley the planet is the only source of Neoplasmin Cubes in the sector\n" +
                "The weather is -20 degrees, Atmosphere reading:\n" +
                "No atmosphere\n" +
                "Best to stay on your scooter and let the drones do the trading.");
            Albynio.inventory = ("Neoplasmin Cubes, Orbs");
            

            Planet Lenoritarium = new Planet();
            Lenoritarium.name = "Lenoritarium";
            Lenoritarium.size = 18000;
            Lenoritarium.description = ("A world wholey dedicated to research and knowlege\n" +
                "Its proximity to Albynio and Carsonopolis ensure a steady supply of research tools and Neoplasmin Cubes allowing the production of hyper drives\n" +
                "The weather is 78 degrees, Atmosphere reading:\n" +
                "O2 70%\n" +
                "CO2 10%\n" +
                "Nitrogen 20%\n" +
                "Stay a while and you might learn a thing or two!");
            Lenoritarium.inventory = ("Food, Fuel, Medals");
               

        }
    }
}
